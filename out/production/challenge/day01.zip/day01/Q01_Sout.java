package day01;

public class Q01_Sout {

    public static void main(String[] args) {

           /*
  Konsolda asagidaki ciktiyi yazdiriniz
        S
        U
        C
        C
        E
        S
        S
        WITH
        C
        L
        A
        R
        U
        S
        W
        A
        Y
         */


        System.out.println("S");
        System.out.println("U");
        System.out.println("C");
        System.out.println("C");
        System.out.println("E");
        System.out.println("S");
        System.out.println(" ");
        System.out.println("WHIT");
        System.out.println("");
        System.out.println("C");
        System.out.println("L");
        System.out.println("A");
        System.out.println("R");
        System.out.println("U");
        System.out.println("S");
        System.out.println("W");
        System.out.println("A");
        System.out.println("Y");
        System.out.println("");

        System.out.println("S");
        System.out.println("U");
        System.out.println("C");
        System.out.println("C");
        System.out.println("E");
        System.out.println("S");
        System.out.println(" ");
        System.out.println("WHIT");
        System.out.println("");
        System.out.println("C");
        System.out.println("L ");
        System.out.println("A ");
        System.out.println("R");
        System.out.println("U");
        System.out.println("S ");
        System.out.println("W");
        System.out.println("A");
        System.out.println("Y ");






















    }


}
